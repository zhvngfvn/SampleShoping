package com.frank.service;

import com.frank.dto.Item;

public interface IItemService {
	public Item getItem(String name);
	public void updateItem(Item item);
}
