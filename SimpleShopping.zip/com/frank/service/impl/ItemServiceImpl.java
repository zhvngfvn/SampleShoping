	package com.frank.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.frank.dto.Item;
import com.frank.service.IItemService;

public class ItemServiceImpl implements IItemService {
	
	public static List<Item> itemList = new ArrayList<Item>();
	
	static {
		setItem();
	}

	@Override
	public Item getItem(String name) {
		// TODO Auto-generated method stub
		for(Item i : itemList) {
			if(i.getName().equals(name)) {
				return i;
			}
		}
		
		return null;
	}

	@Override
	public void updateItem(Item item) {
		// TODO Auto-generated method stub
		for(Item i : itemList) {
			if(i.getName().equals(item.getName())) {
				i.setQuantity(i.getQuantity()-item.getQuantity());
				break;
			}
		}

	}

	public static List<Item> getAllItem() {
		// TODO Auto-generated method stub
		return itemList;
	}
	
	public static void setItem() {
		itemList.clear();
		Item temp1 = new Item();
		temp1.setName("ItemA");
		temp1.setOriginalQuantity(20);
		temp1.setQuantity(temp1.getOriginalQuantity());
		
		itemList.add(temp1);
		
		Item temp2 = new Item();
		temp2.setName("ItemB");
		temp2.setOriginalQuantity(10);
		temp2.setQuantity(temp2.getOriginalQuantity());
		itemList.add(temp2);
	}

}
